# E-commerce Database Schema

## 📌 Overview
This project contains a **sample E-commerce Database Schema** designed as part of the SQL Developer Internship - Task 1.

## 🛠 Schema Design
- Customers place Orders
- Orders contain multiple Products through Order_Items
- Products belong to Categories
- Orders have related Payments

## 📂 Files in this Repo
1. `schema.sql` → SQL script to create the database & tables
2. `ecommerce_er_diagram.png` → ER Diagram of the schema
3. `README.md` → Explanation of schema & instructions

## 📊 ER Diagram
![ER Diagram](ecommerce_er_diagram.png)

## 🚀 How to Run
1. Open MySQL Workbench (or any SQL client)
2. Run the script from `schema.sql`
3. The database `ecommerce_db` will be created with all tables

---

✅ Designed for **SQL Developer Internship Task 1**
